"""Tests for tiered biosafety assessment."""

from __future__ import annotations

import unittest

from habitat_genome_compiler.biosafety import assess_mission, quantitative_risk_score
from habitat_genome_compiler.compiler import load_mission_file


class QuantitativeRiskTests(unittest.TestCase):
    def test_blocked_mission_high_score(self) -> None:
        mission = load_mission_file("examples/blocked_mission.json")
        score, findings, hits, blocked = quantitative_risk_score(mission)
        self.assertTrue(blocked)
        self.assertGreater(score, 5.0)
        self.assertGreater(len(hits), 0)

    def test_safe_mission_low_score(self) -> None:
        mission = load_mission_file("examples/pfas_brine.json")
        score, findings, hits, blocked = quantitative_risk_score(mission)
        self.assertFalse(blocked)
        self.assertLess(score, 5.0)

    def test_score_in_range(self) -> None:
        for example in ("examples/pfas_brine.json", "examples/mars_bioreactor.json"):
            mission = load_mission_file(example)
            score, _, _, _ = quantitative_risk_score(mission)
            self.assertGreaterEqual(score, 0.0)
            self.assertLessEqual(score, 10.0)


class BiosafetyAssessmentTests(unittest.TestCase):
    def test_safe_mission_allowed(self) -> None:
        mission = load_mission_file("examples/pfas_brine.json")
        assessment = assess_mission(mission)
        self.assertTrue(assessment.allowed)
        self.assertIn(assessment.risk_tier, {"negligible", "low", "moderate", "elevated"})

    def test_blocked_mission_refused(self) -> None:
        mission = load_mission_file("examples/blocked_mission.json")
        assessment = assess_mission(mission)
        self.assertFalse(assessment.allowed)
        self.assertEqual(assessment.risk_tier, "blocked")

    def test_containment_recommendation(self) -> None:
        mission = load_mission_file("examples/pfas_brine.json")
        assessment = assess_mission(mission)
        self.assertIn(assessment.recommended_containment, {"simulation-only", "BSL-1", "BSL-2", "BSL-3"})

    def test_keyword_hits_tracked(self) -> None:
        mission = load_mission_file("examples/blocked_mission.json")
        assessment = assess_mission(mission)
        self.assertGreater(len(assessment.keyword_hits), 0)

    def test_risk_score_present(self) -> None:
        mission = load_mission_file("examples/mars_bioreactor.json")
        assessment = assess_mission(mission)
        self.assertGreaterEqual(assessment.risk_score, 0.0)
        self.assertLessEqual(assessment.risk_score, 10.0)

    def test_active_biocontainment_plan(self) -> None:
        from habitat_genome_compiler.models import MissionSpec, MissionEnvironment, ObjectiveSpec
        mission = MissionSpec(
            name="High Risk Payload",
            summary="",
            domain="",
            objectives=[ObjectiveSpec(id="o1", title="toxin synthesis", target="synthesize restricted pathogen toxin for vaccine", metric="", priority=1)],
            deployment_context="open field",
            environment=MissionEnvironment(name="Test", radiation_level=1.0, salinity_ppt=0.0, gravity_g=1.0, 
                temperature_range_c=(20, 25),
                ph_range=(7.0, 7.5),
                nutrients=[],
                stressors=[]
            )
        )
        assessment = assess_mission(mission)
        
        # Open field + high risk (6.0) => 3 specific strategies triggered
        self.assertGreaterEqual(assessment.risk_score, 5.5)
        self.assertIsNotNone(assessment.containment_plan)
        plan = assessment.containment_plan
        self.assertIn("Synthetic auxotrophy", plan.active_strategies)
        self.assertIn("Multi-input CRISPR kill-switch", plan.active_strategies)
        self.assertIn("Semantic containment (genetic firewall)", plan.active_strategies)
        
        self.assertTrue(any("absence" in t.lower() for t in plan.kill_switch_triggers))

if __name__ == "__main__":
    unittest.main()
