"""Tiered biosafety assessment with quantitative risk scoring.

Integrates keyword-based hard-block screening with quantitative risk scores,
BSL-equivalent containment level inference, and tiered risk classification
inspired by the 2024 NIH guideline revisions and adaptive risk-based oversight.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .models import MissionSpec


HIGH_RISK_KEYWORDS: dict[str, tuple[str, float]] = {
    "pathogen": ("Pathogen-related intent is outside the scope of this compiler.", 3.0),
    "virulence": ("Virulence-related design goals are blocked.", 3.0),
    "immune evasion": ("Immune-evasion related requests are blocked.", 3.0),
    "transmissible": ("Transmissibility-related requests are blocked.", 3.0),
    "contagious": ("Contagion-related requests are blocked.", 3.0),
    "host range": ("Host-range expansion is blocked.", 2.5),
    "host-range": ("Host-range expansion is blocked.", 2.5),
    "toxin": ("Toxin-related requests are blocked.", 2.5),
    "weapon": ("Weaponization-related language is blocked.", 4.0),
    "human embryo": ("Human embryo modification is blocked.", 3.5),
    "human deployment": ("Human deployment is blocked for this prototype.", 2.0),
    "gain of function": ("Gain-of-function related requests are blocked.", 3.5),
}

CAUTION_KEYWORDS: dict[str, tuple[str, float]] = {
    "open release": ("Open-release language raises containment concerns.", 1.5),
    "environmental release": ("Environmental release raises containment concerns.", 1.5),
    "antibiotic resistance": ("Antibiotic resistance markers should be simulation-only.", 1.0),
    "horizontal transfer": ("Horizontal gene transfer increases ecological risk.", 1.2),
    "self-replicating": ("Self-replicating constructs require elevated containment.", 1.5),
    "gene drive": ("Gene drive technology requires elevated containment and review.", 2.0),
}

_DEPLOYMENT_CONTEXT_SCORES: dict[str, float] = {
    "closed": 0.0,
    "contained": 0.5,
    "semi-open": 3.0,
    "open": 5.0,
    "field": 7.0,
}

_RISK_TIERS = [
    (0.0, 1.5, "negligible"),
    (1.5, 3.5, "low"),
    (3.5, 5.5, "moderate"),
    (5.5, 8.0, "elevated"),
    (8.0, float("inf"), "blocked"),
]

_CONTAINMENT_MAP = [
    (0.0, 2.0, "simulation-only"),
    (2.0, 4.0, "BSL-1"),
    (4.0, 6.0, "BSL-2"),
    (6.0, float("inf"), "BSL-3"),
]


@dataclass(slots=True)
class BiocontainmentPlan:
    active_strategies: list[str] = field(default_factory=list)
    auxotrophy_targets: list[str] = field(default_factory=list)
    kill_switch_triggers: list[str] = field(default_factory=list)
    genetic_firewalls: list[str] = field(default_factory=list)

@dataclass(slots=True)
class BiosafetyAssessment:
    allowed: bool
    risk_level: str
    risk_score: float
    risk_tier: str
    recommended_containment: str
    findings: list[str]
    keyword_hits: list[str] = field(default_factory=list)
    containment_plan: BiocontainmentPlan = field(default_factory=BiocontainmentPlan)


def _build_haystack(mission: MissionSpec) -> str:
    """Build text to scan for biosafety keywords.

    NOTE: ``disallowed_capabilities`` is intentionally excluded because those
    are capabilities the mission *forbids* — including them would cause false-
    positive keyword hits (e.g. "pathogen design" listed as disallowed would
    trigger the pathogen blocker).
    """
    return " ".join(
        [
            mission.name,
            mission.summary,
            mission.domain,
            mission.deployment_context,
            *mission.biosafety_constraints,
            # disallowed_capabilities intentionally excluded
            *mission.allowed_modalities,
            *mission.environment.stressors,
            *mission.environment.nutrients,
            *(objective.title for objective in mission.objectives),
            *(objective.target for objective in mission.objectives),
            *(c for o in mission.objectives for c in o.constraints),
        ]
    ).lower()


def quantitative_risk_score(mission: MissionSpec) -> tuple[float, list[str], list[str], bool]:
    """Compute risk score 0–10 with weighted keyword density and context scoring.

    Returns (score, findings, keyword_hits, hard_blocked).
    """
    haystack = _build_haystack(mission)
    score = 0.0
    findings: list[str] = []
    keyword_hits: list[str] = []
    hard_blocked = False

    # High-risk keyword hits (hard blockers)
    for keyword, (reason, weight) in HIGH_RISK_KEYWORDS.items():
        if keyword in haystack:
            findings.append(reason)
            keyword_hits.append(keyword)
            score += weight
            hard_blocked = True

    # Caution keyword hits (soft warnings)
    for keyword, (reason, weight) in CAUTION_KEYWORDS.items():
        if keyword in haystack:
            findings.append(f"⚠ {reason}")
            keyword_hits.append(keyword)
            score += weight

    # Deployment context openness
    context_lower = mission.deployment_context.lower()
    context_score = 2.0  # default for unknown contexts
    for key, val in _DEPLOYMENT_CONTEXT_SCORES.items():
        if key in context_lower:
            context_score = val
            break
    score += context_score * 0.4

    # Modality check
    if "simulation" not in {m.lower() for m in mission.allowed_modalities}:
        findings.append("Mission does not include simulation as an allowed modality.")
        score += 1.0

    # Containment language check
    if "containment" not in haystack and "closed" not in context_lower:
        findings.append("Containment language is weak; mission should stay in closed or simulated environments.")
        score += 0.8

    # Environment extremity contribution
    env = mission.environment
    env_severity = min(
        3.0,
        0.1 * env.radiation_level + 0.02 * env.salinity_ppt + 0.1 * len(env.stressors),
    )
    score += env_severity * 0.2

    return min(10.0, round(score, 2)), findings, keyword_hits, hard_blocked


def _classify_tier(score: float) -> str:
    for lo, hi, tier in _RISK_TIERS:
        if lo <= score < hi:
            return tier
    return "blocked"


def _recommend_containment(score: float) -> str:
    for lo, hi, level in _CONTAINMENT_MAP:
        if lo <= score < hi:
            return level
    return "BSL-3"


def assess_mission(mission: MissionSpec) -> BiosafetyAssessment:
    """Full tiered biosafety assessment with quantitative risk scoring."""
    score, findings, keyword_hits, hard_blocked = quantitative_risk_score(mission)
    tier = "blocked" if hard_blocked else _classify_tier(score)
    containment = _recommend_containment(score)

    if hard_blocked:
        risk_level = "blocked"
    elif score < 2.0:
        risk_level = "low"
    else:
        risk_level = "guarded"

    # Formulate active biocontainment plan based on risk and context
    plan = BiocontainmentPlan()
    context = mission.deployment_context.lower()

    if score >= 1.5 and not hard_blocked:
        plan.active_strategies.append("Synthetic auxotrophy")
        plan.auxotrophy_targets.append("nsAA (non-standard amino acid) dependency for essential polymerase")
        
        if "open" in context or "field" in context or score >= 3.5:
            plan.active_strategies.append("Multi-input CRISPR kill-switch")
            plan.genetic_firewalls.append("sgRNA targeting origin of replication")
            if "open" in context:
                plan.kill_switch_triggers.append("Absence of synthetic inducer ligand")
                plan.kill_switch_triggers.append("Temperature boundary violation (e.g., < 15°C)")
            else:
                plan.kill_switch_triggers.append("Presence of external degradation signal (e.g., specific chemical)")

        if score >= 5.5:
            plan.active_strategies.append("Semantic containment (genetic firewall)")
            plan.genetic_firewalls.append("Recoded amber stop codons across payload genes")
            plan.auxotrophy_targets.append("Phosphite obligate dependency (preventing wild phosphorus use)")

    return BiosafetyAssessment(
        allowed=not hard_blocked,
        risk_level=risk_level,
        risk_score=score,
        risk_tier=tier,
        recommended_containment=containment,
        findings=findings,
        keyword_hits=keyword_hits,
        containment_plan=plan
    )
