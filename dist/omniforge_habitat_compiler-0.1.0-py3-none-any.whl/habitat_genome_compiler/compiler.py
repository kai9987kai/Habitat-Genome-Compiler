"""Main mission compilation entrypoints.

Integrates all innovation modules: tiered biosafety, Pareto scoring,
Monte Carlo robustness, DAG analysis, and provenance tracking.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .adapters import build_habitat_profile, propose_candidates
from .biosafety import assess_mission
from .models import CompileResult, MissionSpec, load_json_file
from .planner import build_workflow, critical_path, parallel_groups
from .robustness import robustness_sweep
from .router import select_experts
from .scoring import score_candidates
from .sustainability import evaluate_sustainability
from .metabolism import simulate_flux

__version__ = "0.2.0"

DISCLAIMERS = [
    "This prototype is simulation-first and planning-only.",
    "It does not emit DNA, protein, CRISPR, or laboratory protocol artifacts.",
    "Any transition from simulation to wet-lab work requires biosafety, institutional, and legal review.",
    "Robustness scores are based on Monte Carlo perturbation of environment parameters and are indicative, not definitive.",
    "Economics (TEA) and theoretical yields (FBA) are abstract prospective estimates."
]

def _coerce_mission(payload: MissionSpec | dict[str, Any]) -> MissionSpec:
    if isinstance(payload, MissionSpec):
        return payload
    return MissionSpec.from_dict(payload)

def _compile_metadata(mission: MissionSpec) -> dict[str, Any]:
    """Generate provenance metadata for the compile result."""
    raw = json.dumps(mission.to_dict() if hasattr(mission, "to_dict") else {}, sort_keys=True)
    return {
        "compiler_version": __version__,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "input_hash": hashlib.sha256(raw.encode()).hexdigest()[:16],
    }

def compile_mission(payload: MissionSpec | dict[str, Any]) -> CompileResult:
    mission = _coerce_mission(payload)
    biosafety = assess_mission(mission)
    experts = select_experts(mission)
    workflow = build_workflow(mission, experts)

    # DAG analysis
    cpath = critical_path(workflow)
    pgroups = parallel_groups(workflow)
    dag = {
        "critical_path": cpath,
        "critical_path_length": len(cpath),
        "parallel_groups": pgroups,
        "max_parallelism": max(len(g) for g in pgroups) if pgroups else 0,
    }

    metadata = _compile_metadata(mission)

    if not biosafety.allowed:
        return CompileResult(
            mission=mission,
            allowed=False,
            risk_level=biosafety.risk_level,
            risk_score=biosafety.risk_score,
            risk_tier=biosafety.risk_tier,
            recommended_containment=biosafety.recommended_containment,
            findings=biosafety.findings,
            experts=experts,
            workflow=workflow,
            candidates=[],
            next_steps=[
                "Re-scope the mission to closed, simulation-first industrial or environmental domains.",
                "Remove blocked capabilities from the request.",
            ],
            disclaimers=DISCLAIMERS,
            compile_metadata=metadata,
            dag_analysis=dag,
            containment_plan=biosafety.containment_plan,
        )

    habitat = build_habitat_profile(mission)
    candidates = score_candidates(mission, habitat, propose_candidates(mission, habitat))

    # Monte Carlo robustness sweep
    robustness_reports = robustness_sweep(mission, candidates)
    
    # TEA / LCA Evaluation
    tea_reports = evaluate_sustainability(mission, candidates, habitat.severity)

    for i, candidate in enumerate(candidates):
        candidate.robustness = robustness_reports[i]
        candidate.tea = tea_reports[i]
        candidate.flux = simulate_flux(mission, candidate, habitat)

    next_steps = [
        "Review the top-ranked candidate (Pareto front 0) and its failure modes.",
        "Examine robustness reports for sensitivity to environmental perturbations.",
        "Assess TEA viability score to verify economic scaling feasibility.",
        "Review metabolic bottlenecks and toxicity risks in the flux simulation.",
        "Export the Biocontainment Plan to institutional biosafety committees.",
        "Attach a higher-fidelity habitat simulator or external model adapter behind the workflow stages.",
        "Define institution-specific review gates before any non-simulation activity.",
    ]
    if habitat.severity >= 6:
        next_steps.insert(2, "Prioritize robustness sweeps for thermal, osmotic, and radiation extremes.")

    findings = list(biosafety.findings)
    findings.append(f"Habitat severity score: {habitat.severity}/10.")
    findings.append(habitat.narrative)
    findings.append(f"Quantitative risk score: {biosafety.risk_score}/10  →  tier: {biosafety.risk_tier}.")
    findings.append(f"Recommended containment: {biosafety.recommended_containment}.")

    return CompileResult(
        mission=mission,
        allowed=True,
        risk_level=biosafety.risk_level,
        risk_score=biosafety.risk_score,
        risk_tier=biosafety.risk_tier,
        recommended_containment=biosafety.recommended_containment,
        findings=findings,
        experts=experts,
        workflow=workflow,
        candidates=candidates,
        next_steps=next_steps,
        disclaimers=DISCLAIMERS,
        compile_metadata=metadata,
        dag_analysis=dag,
    )


def load_mission_file(path: str | Path) -> MissionSpec:
    return MissionSpec.from_dict(load_json_file(path))


def render_markdown(result: CompileResult) -> str:
    lines = [
        f"# {result.mission.name}",
        "",
        f"- Allowed: `{str(result.allowed).lower()}`",
        f"- Risk level: `{result.risk_level}`",
        f"- Risk score: `{result.risk_score}/10`",
        f"- Risk tier: `{result.risk_tier}`",
        f"- Recommended containment: `{result.recommended_containment}`",
        f"- Domain: `{result.mission.domain}`",
        f"- Deployment context: `{result.mission.deployment_context}`",
    ]

    # Compile metadata
    if result.compile_metadata:
        lines.extend(["", "## Compile Metadata"])
        for key, val in result.compile_metadata.items():
            lines.append(f"- {key}: `{val}`")

    # Findings
    lines.extend(["", "## Findings"])
    lines.extend(f"- {finding}" for finding in result.findings)

    # Active Biocontainment Plan
    if result.containment_plan and (result.containment_plan.active_strategies or result.containment_plan.kill_switch_triggers):
        lines.extend(["", "## Active Biocontainment Plan"])
        plan = result.containment_plan
        lines.append(f"- **Strategies**: {', '.join(plan.active_strategies)}")
        if plan.auxotrophy_targets:
            lines.append(f"- **Auxotrophy Targets**: {', '.join(plan.auxotrophy_targets)}")
        if plan.kill_switch_triggers:
            lines.append(f"- **Kill-Switch Triggers**: {', '.join(plan.kill_switch_triggers)}")
        if plan.genetic_firewalls:
            lines.append(f"- **Genetic Firewalls**: {', '.join(plan.genetic_firewalls)}")

    # Experts
    lines.extend(["", "## Experts"])
    lines.extend(f"- {expert}" for expert in result.experts)

    # Workflow
    lines.extend(["", "## Workflow"])
    for stage in result.workflow:
        deps = f" (depends: {', '.join(stage.dependencies)})" if stage.dependencies else ""
        lines.append(f"- `{stage.id}` ({stage.owner}): {stage.description}{deps}")

    # DAG Analysis
    if result.dag_analysis:
        lines.extend(["", "## DAG Analysis"])
        if "critical_path" in result.dag_analysis:
            lines.append(f"- **Critical path** ({result.dag_analysis['critical_path_length']} stages): "
                         f"`{'` → `'.join(result.dag_analysis['critical_path'])}`")
        if "max_parallelism" in result.dag_analysis:
            lines.append(f"- **Max parallelism**: {result.dag_analysis['max_parallelism']} stages")
        if "parallel_groups" in result.dag_analysis:
            for i, group in enumerate(result.dag_analysis["parallel_groups"]):
                lines.append(f"  - Level {i}: {', '.join(f'`{s}`' for s in group)}")

    # Candidates
    lines.extend(["", "## Candidates"])
    if not result.candidates:
        lines.append("- No candidates generated because the mission was blocked.")
    else:
        for candidate in result.candidates:
            front = int(candidate.scores.get("pareto_front", 0))
            crowd = candidate.scores.get("crowding_distance", 0)
            crowd_str = "∞" if crowd == float("inf") else f"{crowd:.2f}"
            lines.append(f"### {candidate.title} (Pareto front {front})")
            lines.append(
                f"- **Total**: `{candidate.scores.get('total', 0)}` | "
                f"mission `{candidate.scores.get('mission_fit', 0)}` | habitat `{candidate.scores.get('habitat_fit', 0)}` | "
                f"feasibility `{candidate.scores.get('feasibility', 0)}` | biosafety `{candidate.scores.get('biosafety_margin', 0)}`"
            )
            lines.append(f"- **Crowding distance**: `{crowd_str}`")
            lines.append(f"- **Archetype**: `{candidate.archetype}`")
            if candidate.tea:
                tea = candidate.tea
                lines.append(f"- **TEA / LCA**: Viability `{tea.viability_score}/10` | "
                             f"CAPEX `M${tea.estimated_capex_usd_k / 1000:.2f}` | "
                             f"OPEX `M$/yr {tea.estimated_opex_usd_k_yr / 1000:.2f}` | "
                             f"EROI `{tea.energy_return_on_investment}` | "
                             f"CO2e `{tea.carbon_footprint_kg_co2_kg_prod} kg/kg`")
                if tea.cost_drivers:
                    lines.append(f"  - Drivers: {', '.join(tea.cost_drivers)}")
                    
            if candidate.flux:
                flux = candidate.flux
                lines.append(f"- **Metabolic Flux**: Theoretical Yield `{flux.theoretical_yield:.1%}` | "
                             f"Burden `{flux.metabolic_burden}` | Tox Risk `{flux.toxic_intermediate_risk}`" +
                             (f" | Limiting: `{flux.limiting_nutrient}`" if flux.limiting_nutrient else ""))
                if flux.pathway_bottlenecks:
                    lines.append(f"  - Bottlenecks: {', '.join(flux.pathway_bottlenecks)}")
                    
            lines.append(f"- Summary: {candidate.summary}")
            lines.append(f"- Modules: {', '.join(candidate.modules)}")
            lines.append(f"- Risks: {', '.join(candidate.risks)}")

            # Robustness annotation
            if candidate.robustness:
                r = candidate.robustness
                lines.append(f"- **Robustness**: mean `{r.mean_total}` ± `{r.std_total}` | "
                             f"failure rate `{r.failure_rate:.1%}`")
                if r.sensitivity:
                    sens_parts = [f"{k}: `{v:+.4f}`" for k, v in r.sensitivity.items()]
                    lines.append(f"  - Sensitivity: {', '.join(sens_parts)}")

    # Next Steps
    lines.extend(["", "## Next Steps"])
    lines.extend(f"- {step}" for step in result.next_steps)

    # Disclaimers
    lines.extend(["", "## Disclaimers"])
    lines.extend(f"- {item}" for item in result.disclaimers)
    return "\n".join(lines)
